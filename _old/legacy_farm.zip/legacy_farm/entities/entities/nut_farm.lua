AddCSLuaFile()

ENT.Type = "anim"
ENT.PrintName = "Mushroom Farm"
ENT.Author = "dickmosi"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "NutScript - Farm"

ENT.growthDelay = 86400 -- 1 day: How long the mushrooms take to grow (in seconds) 
ENT.growthStageTimer = 1800 -- 30 minutes: How often the growth stage timer should run (in seconds) 

if (SERVER) then
	function ENT:Initialize()
		self:SetModel("models/farm/mushroom_farm.mdl") -- Requires content (1, 2 and 3) https://steamcommunity.com/sharedfiles/filedetails/?id=1567871325
		self:SetSolid(SOLID_VPHYSICS) -- shitty model slapped together by dickmosi :)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		
		timerDelay = 0

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		else
			local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

			self:PhysicsInitBox(min, max)
			self:SetCollisionBounds(min, max)
		end
	end
	
function ENT:SpawnFunction(client, trace)
	local angles = (trace.HitPos - client:GetPos()):Angle()
	angles.r = 0
	angles.p = 0
	angles.y = 0 + 90 -- Makes it face the person who spawns it in, FANCY!

	local ent = ents.Create( ClassName )
	ent:SetPos(trace.HitPos)
	ent:SetAngles(angles)
	ent:Spawn()
	
	return ent

end

function ENT:Think()
	
	if self:getNetVar("timerShouldRun") and self:getNetVar("plantState") then -- Incase farm is harvested mid-timer
		if self:getNetVar("growthTime") < os.time() then
			self:SetBodygroup(1, 3) -- Fully grown
			self:setNetVar("timerShouldRun", false)
		elseif ((self:getNetVar("growthTime") - (self.growthDelay / 2)) < os.time()) then
			self:SetBodygroup(1, 2) -- Half Grown
		else end
	end

	timerDelay = CurTime() + self.growthStageTimer
	self:NextThink(timerDelay) -- Set the next think to run as soon as possible, i.e. the next frame.
	return true
end

-----------------------------------------------------

function ENT:Use(activator)
--Timer to prevent people spamming E on this entity.
if (nextUse or 0) > CurTime() then -- Prevents overlap as opposed to activator.nextUse (Which could lead to potential overlap)
	return false
end

nextUse = CurTime() + 2
activator.hasWater = 0 -- this is why
activator.waterCheck = 0

local char = activator:getChar()
local inventory = char:getInv()
local getPlantState = self:getNetVar("plantState")

if !char:hasFlags("F") then
	activator:notify("You do not have permission to use this farm.")
	return false
end

if getPlantState == false then
	for k, v in pairs( inventory:getItems() ) do
		if v.isFillable and v:getData("filled", nil) ~= nil then
			activator.hasWater = 1 -- If the activator has Water
		end
	end
	
	if activator.hasWater == 0 then -- If the activator doesn't have water
		activator:notify("You need both mushroom seeds and water to plant here.")
		return false
	else activator.hasWater = 0 end
end

---------------------------THIS IS WHERE THE PLANTING AND HARVESTING ACTUALLY HAPPENS


if getPlantState == false or getPlantState == nil then -- Setting plantstate on init may overwrite plugin save data
	if inventory:hasItem("mushroom_seeds") and inventory:hasItem("farm_water") then -- If both true then plant
	
		local seeds = inventory:getFirstItemOfType("mushroom_seeds")
		
		self:EmitSound("physics/cardboard/cardboard_box_impact_hard"..math.random(1,7)..".wav")
		self:setNetVar("plantState", true)
		self:setNetVar("farmPlayer", char:getName())
		self:setNetVar("growthTime", os.time() + self.growthDelay)
		nut.log.addRaw(activator:getChar():getName().." has planted some mushrooms.")
		
		seeds:remove()
		
		for k, v in pairs( inventory:getItems() ) do
			if v.isFillable and v:getData("filled", nil) ~= nil and activator.waterCheck == 0 then
				activator.waterCheck = 1
				v:setData("filled", nil)
			end
		end
		
		activator.waterCheck = 0
		
		self:SetBodygroup(1, 1)
		activator:notify("You have planted some mushrooms.")
		self:setNetVar("timerShouldRun", true) -- Turns on stupid bodygroup update timer
		
	else
		activator:notify("You need both mushroom seeds and water to plant here.")
	end
end
	if getPlantState == true then
		if self:getNetVar("growthTime") < os.time() then -- If something is planted and it's ready, let me harvest mofo
			self:EmitSound("physics/cardboard/cardboard_box_impact_bullet"..math.random(1,5)..".wav")
			self:EmitSound("npc/barnacle/barnacle_crunch"..math.random(2,3)..".wav")
			self:EmitSound("physics/wood/wood_strain"..math.random(1,6)..".wav")
			
			self:setNetVar("timerShouldRun", false)
			self:setNetVar("plantState", false)
			self:SetBodygroup(1, 0)
	
			nut.item.spawn("mushroom_crate", activator:getItemDropPos())
			
			activator:notify("You have harvested the mushrooms and packed them into a crate.")
			nut.log.addRaw(activator:getChar():getName().." has gained a mushroom crate from farming.")
			
		else
			activator:notify("The mushrooms have not grown yet.")
		end
		return false
	end
end
----------------------------------------------------THIS IS WHERE IT ENDS AND WHERE THE BORING UI CODE BEGINS
else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
		
			local getPlantState = self:getNetVar("plantState")
			
			if getPlantState == false or getPlantState == nil then
				entDesc = "Nothing is planted here right now."
			else
				local growthDate = os.date("%X %p on %d/%m/%y", self:getNetVar("growthTime")) 
				local farmPlayer = self:getNetVar("farmPlayer") -- Displays who planted this, incase people start nabbing others spots. There should probably be an owner system but meh.
				entDesc = ("Growing Mushrooms planted by "..farmPlayer..". Harvestable at "..growthDate)
			end											-- Display date and time that crops will be fully grown
		
		drawText(entDesc, x, y+25, Color(255, 255, 255, alpha), 1, 1, nil, alpha * 0.65)
	end
end