AddCSLuaFile()

ENT.Base = "nut_foraging_base"
ENT.PrintName = "Wild Mushroom Cluster"
ENT.Desc = "A small cluster of edible mushrooms sought-after by farmers"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "NutScript - Farm"

ENT.model = "models/illusion/metroexodus/mushroom.mdl"
ENT.forageReward = "mushroom_cluster"