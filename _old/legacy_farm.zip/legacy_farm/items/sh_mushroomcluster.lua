ITEM.name = "Wild Mushroom Cluster"
ITEM.desc = "A cluster of wild mushrooms, often saught by farmers for their spores."
ITEM.model = "models/illusion/metroexodus/mushroom.mdl"
ITEM.uniqueID = "mushroom_cluster"

ITEM.price = 30

ITEM.functions.convert = { 
	name = "Convert",
	tip = "Converts the cluster into seeds",
	icon = "icon16/arrow_switch.png",
	onRun = function(item)
		local client = item.player
		local char = client:getChar()
		local inventory = char:getInv()
		
		client:EmitSound("npc/barnacle/neck_snap"..math.random(1,2)..".wav")
		inventory:add("mushroom_seeds")
		
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity) and item.player:getChar():hasFlags("F"))
	end
}

ITEM.functions._seperate = { 
	name = "Break Apart",
	tip = "Breaks the cluster into regular mushrooms",
	icon = "icon16/arrow_divide.png",
	onRun = function(item)
		local client = item.player
		local char = client:getChar()
		local inventory = char:getInv()
			
		client:EmitSound("npc/barnacle/neck_snap"..math.random(1,2)..".wav")
		
		for i=4,1,-1 do -- pasting the same line 4 times is really hard!!!
		inventory:add("mushroom")
		end
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity))
	end
}