ITEM.name = "Mushroom Crate"
ITEM.desc = "A crate of tightly packed with mushrooms."
ITEM.model = "models/devcon/mrp/props/weapon_shipment.mdl"
ITEM.uniqueID = "mushroom_crate"

ITEM.width = 2
ITEM.height = 1

ITEM.price = 30

ITEM:hook("take", function(item)
	local client = item.player
	local inventory = client:getChar():getInv()
	
	local freeSpot = inventory:findFreePosition(item)
	
	if freeSpot == nil then
		client:notify("Your inventory is full.")
		return false
	end
end)