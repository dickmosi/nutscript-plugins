ITEM.name = "Mushroom Spawn"
ITEM.desc = "These seeds can be used to grow mushrooms"
ITEM.model = "models/props_lab/box01b.mdl"
ITEM.uniqueID = "mushroom_seeds"

ITEM.width = 1
ITEM.height = 1