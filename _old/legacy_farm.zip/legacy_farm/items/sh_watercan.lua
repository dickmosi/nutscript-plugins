ITEM.name = "Jerrycan"
ITEM.desc = "An empty metal jerrycan that can be filled with water."
ITEM.model = "models/props_junk/metalgascan.mdl"
ITEM.uniqueID = "farm_water"

ITEM.isFillable = true

ITEM.functions._empty = { 
	name = "Empty",
	tip = "Empty the jerrycan out",
	icon = "icon16/bin.png",
	onRun = function(item)
		local client = item.player
		
		item:setData("filled", nil)
		client:EmitSound("ambient/water_splash"..math.random(1,3)..".wav")
		
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity) and item:getData("filled"))
	end
}

-------------------------------------------------------------

function ITEM:getName()
	local name = self.name
	
	if self:getData("filled", nil) ~= nil then
		name = ("Filled ".. self.name .." (Water)")
	else name = ("Empty "..self.name) end
	
	return Format(name)
end

function ITEM:getDesc()
	local desc = self.desc
	
	if self:getData("filled", nil) ~= nil then
		desc = ("A jerrycan filled with water.")
	else desc = self.desc end
	
	return Format(desc)
end

if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		
		if item:getData("filled") then
			draw.SimpleText("Full", "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
		else
			draw.SimpleText("Empty", "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
		end
	end
end