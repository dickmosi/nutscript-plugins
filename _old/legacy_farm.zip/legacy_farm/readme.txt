This plugin is provided as-is, do whatever you want with it. I will not be providing support for it.

This plugin was intended as a small plugin for mushroom farming in Metro Serious RP as a way to have farming with out any admin involvement required.

Only certain people with permissions can plant at the farms, they need seeds and water to do so. They got seeds/spores from mushroom clusters that could be found out in the tunnels, these clusters could be broken into mushrooms or converted into seeds. This was to allow players to forage but also allow them to get nice paycheck if they knew what they had found. This creates a little bounty system where players are encouraged to go outside and find mushroom clusters, putting them at risk but for a nice reward.

Anyway, that's all. You can delete this now, okay byeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee