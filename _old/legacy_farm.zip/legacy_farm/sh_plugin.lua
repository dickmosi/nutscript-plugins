PLUGIN.name = "Mushroom Farming"
PLUGIN.author = "dickmosi, the mushroom man"
PLUGIN.desc = "A relatively simple farm plugin for Nutscript 1.1-beta"

-- This addon requires you to add the 'F' flag yourself, yeah I should make this a config but I won't

if SERVER then

	function PLUGIN:LoadData()
		local restored = self:getData()

		if (restored) then
			for k, v in pairs(restored) do
				local position = v.position
				local angles = v.angles
				local plantState = v.plantState
				local growthTime = v.growthTime
				local farmPlayer = v.farmPlayer
				local bodygroup = v.bodygroup

				local entity = ents.Create("nut_farm")
				entity:SetPos(position)
				entity:SetAngles(angles)
				entity:Spawn()
				entity:Activate()
				entity:setNetVar("plantState", plantState)
				entity:setNetVar("growthTime", growthTime)
				entity:setNetVar("farmPlayer", farmPlayer)
				entity:SetBodygroup(1, bodygroup)
			end
		end
end
	function PLUGIN:SaveData()
		local data = {}
	
		for k, v in pairs(ents.FindByClass("nut_farm")) do
			data[#data + 1] = {
				position = v:GetPos(),
				angles = v:GetAngles(),
				plantState = v:getNetVar("plantState"),
				growthTime = v:getNetVar("growthTime"),
				farmPlayer = v:getNetVar("farmPlayer"),
				bodygroup = v:GetBodygroup(1),
			}
		end
	
			self:setData(data)
		end
	end