ITEM.name = "Example - Metro Cop Uniform"
ITEM.desc = "Example Armour"
ITEM.category = "Outfit"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.outfitCategory = "model"

ITEM.armor = 100 -- Default Durability. Use item.dmgReduction to decide the armour's strength

ITEM.dmgReduction = .8 	-- 0 to 1 (The lower, the more dmg reduction [DMG * Reduction = Final DMG])
ITEM.moveSpeedModifier = .65	-- 0 to 1 (The lower the more it reduces movement speed [MoveSpeed * Mod = Final MoveSpeed])

ITEM.replacements = "models/Police.mdl"

--[[
	- !!EXPLAINATION!! -

This plugin changes the behaviour of armour. If a player is hurt and has armour, all damage will be done to the armour.
If they do not have armour, the damage will be dealt to their health instead, like normal.
I have patched the abillity to re-equip an outfit to regain armour. Armour now = durability and armour

DMG Reduction will reduce damage taken whilst armour remains.

Movement Speed Modifier will apply whilst the outfit is equipped, regardless of if any armour remains.

item.armor still controls how much armour is given but it also serves the purpose of how much durability the outfit's armour has.
--]]