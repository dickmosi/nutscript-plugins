ITEM.name = "Repair Kit"
ITEM.desc = "A repair kit that includes the all the tools needed to fully repair weaponry and equipment."
ITEM.model = "models/z-o-m-b-i-e/metro_2033/cases/m33_case_02.mdl"
ITEM.uniqueID = "repairkit_professional"

ITEM.Uses = 8
ITEM.rechargeFee = 12
ITEM.healAmount = 25 -- Heals X Durability per Charge

ITEM.functions._Refill = {
	name = "Refill 1 Charge (-12 MGR)", -- Change this shit if you alter item.rechargeFee
	tip = "Adds an additional use at the cost of bullets",
	icon = "icon16/cog_add.png",
	onRun = function(item)
		local client = item.player
		local char = client:getChar()
		local inventory = char:getInv()
		local Uses = item:getData("Uses", item.Uses) or item.Uses
		
		if char:getMoney() < item.rechargeFee then
			client:notify("You don't have enough bullets to do this.")
			return false
		end
		
		char:setMoney(char:getMoney() - item.rechargeFee)
		item:setData("Uses", Uses + 1)	
		
	return false
end,
	onCanRun = function(item)
		local usesLeft = item:getData("Uses", item.Uses) or item.Uses

		return (!IsValid(item.entity) and item.player:getChar():hasFlags("W") or item.player:getChar():hasFlags("A") and usesLeft < item.Uses)
	end
}

if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		local usesLeft = item:getData("Uses", item.Amount) or item.Uses
	
		draw.SimpleText(usesLeft.."/"..item.Uses, "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end