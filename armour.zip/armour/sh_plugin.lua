PLUGIN.name = "Armour" -- spelt correctly B-)
PLUGIN.author = "dickmosi"
PLUGIN.desc = "Makes armour more armoury"

nut.flag.add("A", "Access to armorsmith perks - requires additional items.")

hook.Add( "EntityTakeDamage", "armourDmg", function( target, dmginfo )

	if !dmginfo:IsDamageType(DMG_FALL) and !dmginfo:IsDamageType(DMG_DROWN) then
		if target:IsPlayer() and target:Armor() > 0 then
			local newDmg = (dmginfo:GetDamage() * target:getChar():getData("armorBonus", 1))
			
			if dmginfo:GetAttacker():IsPlayer() and dmginfo:GetAttacker():GetActiveWeapon():GetClass() == "nut_hands" then
				-- Armour dmg is hardcoded, so this effectively nerfs dmg dealt by fists to lessen griefing.
			else
				target:SetArmor(math.max(target:Armor() - newDmg, 0))
			end
			
			target:EmitSound("physics/metal/metal_canister_impact_soft"..math.random(1,3)..".wav", 100, math.random(150,255))
	
			for k, v in pairs(target:getChar():getInv():getItems()) do
				if v:getData("equip", nil) and v.armor > 0 then
					v:setData("health", target:Armor())
				end
			end
	
			dmginfo:SetDamage(0) -- Prevents health dmg if armour still exists
		end	-- Could be improved by adding a dmg remainder system. 1 Armour can absord any amount of damage and it won't carry over to HP as-is.
	end
end)