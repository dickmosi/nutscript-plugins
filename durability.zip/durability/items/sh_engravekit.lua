ITEM.name = "Engraving Kit"
ITEM.desc = "An engraving kit that includes the all the tools needed to engrave weapons."
ITEM.model = "models/props_lab/box01b.mdl"
ITEM.uniqueID = "engravekit"

ITEM.Uses = 10
ITEM.rechargeFee = 8

ITEM.functions._Refill = {
	name = "Refill 1 Charge (-8 MGR)", -- Change this shit if you alter item.rechargeFee
	tip = "Adds an additional use at the cost of bullets",
	icon = "icon16/cog_add.png",
	onRun = function(item)
		local client = item.player
		local char = client:getChar()
		local inventory = char:getInv()
		local Uses = item:getData("Uses", item.Uses) or item.Uses
		
		if char:getMoney() < item.rechargeFee then
			client:notify("You don't have enough bullets to do this.")
			return false
		end
		
		char:setMoney(char:getMoney() - item.rechargeFee)
		item:setData("Uses", Uses + 1)	
		
	return false
end,
	onCanRun = function(item)
		local usesLeft = item:getData("Uses", item.Uses) or item.Uses

		return (!IsValid(item.entity) and item.player:getChar():hasFlags("W") and usesLeft < item.Uses)
	end
}

-----------------------------------------------------------------------------------------------
if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		local usesLeft = item:getData("Uses", item.Amount) or item.Uses
	
		draw.SimpleText(usesLeft.."/"..item.Uses, "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end