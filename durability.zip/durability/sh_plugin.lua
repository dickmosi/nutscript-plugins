PLUGIN.name = "Durability/Repair Plugin"
PLUGIN.author = "dickmosi"
PLUGIN.desc = "A simple durability and repair plugin for Nutscript 1.1-beta"

nut.flag.add("W", "Access to weaponsmith perks - requires additional items.")

if (SERVER) then
	function PLUGIN:EntityFireBullets(entity) -- entity, bullet (so my ass don't need to look it up again)
	
	if entity:IsPlayer() and entity:IsValid() then
	
		local char = entity:getChar()
		local inventory = char:getInv()
		local curWeapon = entity:GetActiveWeapon():GetClass()
		
			for k, v in pairs(inventory:getItems()) do
				
				if v.class == curWeapon and v:getData("equip", nil) then
					if v.noDurability == true then return end -- Alows to opt-out certain guns from using this shit
					
					local curHealth = v:getData("health", v.defaultHealth) or v.defaultHealth
					
					if math.random(1, v.damageChance) == 1 then
						v:setData("health", math.max(0, curHealth - math.max(0, math.random(0,10))))
					end

					if curHealth == 0 then
						v:setData("equip", nil)
						entity.carryWeapons = entity.carryWeapons or {}
	
						local weapon = entity.carryWeapons[v.weaponCategory]
						if (!IsValid(weapon)) then
							weapon = entity:GetWeapon(v.class)
						end
			
						if (IsValid(weapon)) then
							v:setData("ammo", weapon:Clip1())
	
							entity:StripWeapon(v.class)
							entity.carryWeapons[v.weaponCategory] = nil
							entity:EmitSound("items/ammo_pickup.wav", 80)
							
						end
					end
					-- print(curHealth)
					-- I can add bullet shit here if I want (update: i don't want)
				end
			end
		end
	end
end--my suffering