local PLUGIN = PLUGIN
PLUGIN.name = "FORAGE Spawner"
PLUGIN.author = "Black Tea (NS 1.0), Neon (NS 1.1)"
PLUGIN.desc = "forage Spawner."
PLUGIN.foragepoints = PLUGIN.foragepoints or {}

nut.config.add("spawner_enabled", true, "Whether forage spawners are on or not.", nil, {
	category = "forage Spawner"
})

nut.config.add("forage_spawnrate", 90, "How often an forage will be spawned at an forage spawn point.", nil, {
	data = {min = 1, max = 84600},
	category = "forage Spawner"
})

nut.config.add("forage_maxforages", 16, "How many forages the spawner is allowed to spawn at once.", nil, {
	data = {min = 1, max = 84600},
	category = "forage Spawner"
})

PLUGIN.foragespawngroups = {
["all"] = {
	"nut_foraging_mushrooms",
	"nut_foraging_glowshrooms",
	"nut_foraging_nettle"
},

["nettle"] = {
	"nut_foraging_nettle"
},

["mushrooms"] = {
	"nut_foraging_mushrooms",
	"nut_foraging_glowshrooms"
},
}

PLUGIN.maxforage = 100
PLUGIN.spawnedforage = PLUGIN.spawnedforage or {}

if SERVER then
	local spawntime = 1
	
	function PLUGIN:Think()
		if spawntime > CurTime() then return end
		spawntime = CurTime() + nut.config.get("forage_spawnrate", 90)
		for k, v in ipairs(self.spawnedforage) do
			if (!v:IsValid()) then
				table.remove(self.spawnedforage, k)
			end
		end

		if #self.spawnedforage >= nut.config.get("forage_maxforage", 40) then return end

		local v = table.Random(self.foragepoints)

		if(!nut.config.get("spawner_enabled", false)) then
			return
		end
		
		if (!v) then
			return
		end

		local data = {}
		data.start = v[1]
		data.endpos = data.start + Vector(0, 0, 1)
		data.filter = client
		data.mins = Vector(-16, -16, 0)
		data.maxs = Vector(16, 16, 16)

		if(!self.foragespawngroups) then
			return
		end		
		
		local idat = table.Random(self.foragespawngroups[v[2]] or self.spawngroup["default"])

		--nut.item.spawn(idat, v[1] + Vector( math.Rand(-8,8), math.Rand(-8,8), 20 ), nil, AngleRand())
			
		local trace = util.TraceHull(data)

		
		local nearby = false 
		local players = player.GetAll()
		
		--dont want to spawn them in too close to players
		if(players) then
			for k, v in pairs(players) do
				if(v:GetMoveType() == MOVETYPE_NOCLIP) then
					continue
				end
			
				if v:GetPos():DistToSqr(data.endpos) < 1000 * 1000 then --squared is more efficient
					nearby = true
					break
				end
			end
		end
		
		if (!nearby and !trace.Entity:IsValid()) then --dont want the forage to stack on each other or spawn inside something.
			local ent = ents.Create(idat)
			
			table.insert(self.spawnedforage, ent)
				
			if (ent:IsValid()) then
				ent:SetPos(data.endpos + Vector(0,0,-2))
				ent:Spawn()
			end
		end
	end

	function PLUGIN:LoadData()
		self.foragepoints = self:getData() or {}
	end

	function PLUGIN:SaveData()
		self:setData(self.foragepoints)
	end

else

	netstream.Hook("nut_DisplaySpawnPoints", function(data)
		for k, v in pairs(data) do
			local emitter = ParticleEmitter( v[1] )
			local smoke = emitter:Add( "sprites/glow04_noz", v[1] )
			smoke:SetVelocity( Vector( 0, 0, 1 ) )
			smoke:SetDieTime(10)
			smoke:SetStartAlpha(255)
			smoke:SetEndAlpha(255)
			smoke:SetStartSize(64)
			smoke:SetEndSize(64)
			smoke:SetColor(255,50,50)
			smoke:SetAirResistance(300)
		end
	end)

end

nut.command.add("foragespawnadd", {
	adminOnly = true,
	syntax = "<string foragegroup>",
	onRun = function(client, arguments)
		local trace = client:GetEyeTraceNoCursor()
		local hitpos = trace.HitPos + trace.HitNormal*5
		local spawngroup = arguments[1] or "default"
		
		if(PLUGIN.foragespawngroups[spawngroup]) then
			table.insert(PLUGIN.foragepoints, {hitpos, spawngroup})
			client:notify("You added ".. spawngroup .. " forage spawner.")
		else
			client:notify("Invalid spawngroup.")
		end
	end
})

nut.command.add("foragespawnremove", {
	adminOnly = true,
	onRun = function(client, arguments)
		local trace = client:GetEyeTraceNoCursor()
		local hitpos = trace.HitPos + trace.HitNormal*5
		local range = arguments[1] or 128
		local mt = 0
		
		for k, v in pairs( PLUGIN.foragepoints ) do
			local distance = v[1]:DistToSqr(hitpos)
			if distance <= tonumber(range) * tonumber(range) then
				PLUGIN.foragepoints[k] = nil
				mt = mt + 1
			end
		end
		
		client:notify(mt .. " forage spawners has been removed.")
	end
})

nut.command.add("foragespawndisplay", {
	adminOnly = true,
	onRun = function(client, arguments)
		if SERVER then
			netstream.Start(client, "nut_DisplaySpawnPoints", PLUGIN.foragepoints)
			client:notify("Displayed All Points for 10 secs.")
		end
	end
})

nut.command.add("foragespawntoggle", {
	adminOnly = true,
	onRun = function(client, arguments)
		if(nut.config.get("spawner_enabled", false)) then
			nut.config.set("spawner_enabled", false)
			client:notify("FORAGE Spawners have been turned off.")
		else
			nut.config.set("spawner_enabled", true)
			client:notify("FORAGE Spawners have been turned on.")
		end
	end
})