ATTRIBUTE.name = "Brewing"
ATTRIBUTE.desc = "Affects the quality your alcohol and the likelyhood of success."