ATTRIBUTE.name = "Farming"
ATTRIBUTE.desc = "Affects the quality of crops, and the likely hood getting seeds back from your harvests."