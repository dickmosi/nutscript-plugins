ENT.isWipeable = true
ENT.isOwnable = true
ENT.isFarmAnimal = true -- Don't change this.

ENT.Type = "anim"
ENT.PrintName = "Farm Animal Base"
ENT.Author = "dickmosi"
ENT.Category = "NutScript - Industry"
ENT.Spawnable = false
ENT.AdminOnly = true

ENT.animalModel = "models/props_c17/TrapPropeller_Engine.mdl"
ENT.animalType = nil

ENT.idleSound = "metro/industry/animals/rat_idle_"..math.random(1,9)..".wav", 60, math.random(90,130), math.random(.7,1)
ENT.idleSoundFormat = ".wav"
ENT.idleSoundAmt = 9 -- Total amount of idle sounds
ENT.idleSoundFreq = 5 -- seconds (+ 0-10 seconds)

ENT.flagRequired = "F" -- set to nil if you don't want a flag.

ENT.noProduceMSG = "There are no eggs to collect, but the Chickens are now hungry."
ENT.produceMSG = "You collect an egg." -- Actual message: "You collect an egg. (x3)"
ENT.produceItem = "egg"
ENT.produceItemAmtMin = 2
ENT.produceItemAmtMax = 4
ENT.produceFailChance = 50

if (SERVER) then
	function ENT:Initialize()
		self:SetModel(self.animalModel)
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		else
			local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

			self:PhysicsInitBox(min, max)
			self:SetCollisionBounds(min, max)
		end
	end
--FILL CODE-----------------------------------
function ENT:animalFeed(feedTime, characterName)
	if self:getNetVar("whenCheckable", nil) == nil then
		self:setNetVar("whenCheckable", os.time() + feedTime)
		self:setNetVar("characterName", characterName)
		nut.log.addRaw(characterName.." has fed a "..self.PrintName)
	else 
		return false
	end
end

function ENT:entityOwnerCheck(player)
	local character = player:getChar()
	local charName = character:getName()
	local faction = character:getFaction()
	local owner = self:getNetVar("owner", nil)
	
	self.faction = false
	self.player = false
	
	if owner != nil then
		if owner == faction then
			self.faction = true
		end
		
		if owner == charName then
			self.player = true
		end
		
		return self.faction or self.player or false
	else return true end
end
--
function ENT:entityWipe()
	self:setNetVar("whenCheckable", nil)
	self:setNetVar("characterName", nil)
end
--
function ENT:Think()
	if math.random(1,10) == 1 then -- No need to constantly run this I guess.
		if self:getNetVar("persistent") then
			nut.log.addRaw("ATTENTION: ANIMAL FARM REMOVED. Please do not persist the farms, animals or fermenting barrels as they automatically persist themselves. Manually persisting them can lead to server lag and data loss.")
			self:Remove()
		end
	end

	if self.idleSound != nil then
		self:EmitSound(self.idleSound..math.random(1,self.idleSoundAmt)..self.idleSoundFormat, 70, math.random(90,130), math.random(.7,1))
	end

	self:NextThink(CurTime() + (self.idleSoundFreq + math.random(0,10)))
	return true
end
--HARVESTING CODE-------------------------------------
function ENT:Use(activator)
	if !self:entityOwnerCheck(activator) then
		return false
	end

	if self.flagRequired != nil and !activator:getChar():hasFlags(self.flagRequired) then
		return false
	end

	if (self.nextUse or 0) > CurTime() then
		return false
	end

	self.nextUse = CurTime() + 7

	if self:getNetVar("whenCheckable") != nil then
		if self:getNetVar("whenCheckable") <= os.time() then
	
		local oldPos = activator:GetPos()
		
			activator:setAction("Checking Animals...", 5, function()
				if(activator:GetPos():Distance(oldPos) > 50) then
					activator:notify("Failed, too far away.")
					return false
				end

				if math.random(1,100) <= self.produceFailChance then
					self:setNetVar("whenCheckable", nil)
					self:setNetVar("characterName", nil)
					
					activator:notify(self.noProduceMSG)
					return false
				end
				
				local produceAmtRNG = math.random(self.produceItemAmtMin,self.produceItemAmtMax)
				
				for i= produceAmtRNG,1,-1 do 
					nut.item.spawn(self.produceItem, activator:getItemDropPos())
				end
				nut.log.addRaw(activator:getChar():getName().." produce from "..self.PrintName)
				activator:notify(self.produceMSG.." (x"..produceAmtRNG..")")
				
				self:setNetVar("whenCheckable", nil)
				self:setNetVar("characterName", nil)
			end)
		else
			activator:notify("The "..self.PrintName.." seems busy at the moment. You should check in later.")
		end
	else
		activator:notify("The animals in the "..self.PrintName.." are hungry.")
	end
end
--
--UI CODE--------------------------------------------
else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
		
		local faction = nut.faction.indices[self:getNetVar("owner", nil)]
		
		if self:getNetVar("owner", nil) != nil then
			if faction then
				drawText("Owned by: "..faction.name.." Faction", x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			else
				drawText("Owned by: "..self:getNetVar("owner", nil), x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			end
		end

		if self:getNetVar("whenCheckable") != nil then
			local checkDate = os.date("%X %p on %d/%m/%y", self:getNetVar("whenCheckable")) 
			local characterName = self:getNetVar("characterName") -- Displays who planted the crops

			entDesc = ("Animals Last fed by "..characterName..". They'll be hungry again by "..checkDate)
		else
			entDesc = ("The animals in the "..self.PrintName.." seem hungry.")
		end

		drawText(entDesc, x, y+25, Color(255, 255, 255, alpha), 1, 1, nil, alpha * 0.65)
	end
end