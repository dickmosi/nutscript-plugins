ENT.Spawnable = true
ENT.Base = "nut_animal_base"
ENT.Category = "NutScript - Industry"
ENT.PrintName = "Pig Pen"

ENT.animalModel = "models/mosi/metro/animals/pig_cage.mdl"
ENT.animalType = "pigs"

ENT.idleSound = "metro/industry/animals/pig_idle_"
ENT.idleSoundAmt = 7 -- Total amount of idle sounds
ENT.idleSoundFreq = 30 -- seconds (+ 0-10 seconds)

ENT.noProduceMSG = "There are no offspring to cull, however the pigs are hungry."
ENT.produceMSG = "You remove a pig from the pen and slaughter it." -- Actual message: "You collect an egg. (x3)"
ENT.produceItem = "pig"
ENT.produceItemAmtMin = 1
ENT.produceItemAmtMax = 2
ENT.produceFailChance = 80