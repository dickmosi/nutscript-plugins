ENT.Spawnable = true
ENT.Base = "nut_animal_base"
ENT.Category = "NutScript - Industry"
ENT.PrintName = "Rat Cage"

ENT.animalModel = "models/mosi/metro/animals/rat_cage.mdl"
ENT.animalType = "rats"

ENT.idleSound = "metro/industry/animals/rat_idle_"
ENT.idleSoundAmt = 9 -- Total amount of idle sounds
ENT.idleSoundFreq = 5 -- seconds (+ 0-10 seconds)

ENT.noProduceMSG = "There are no offspring to cull, however the rats are hungry."
ENT.produceMSG = "You remove a rat from the cage and slaughter it." -- Actual message: "You collect an egg. (x3)"
ENT.produceItem = "rat"
ENT.produceItemAmtMin = 1
ENT.produceItemAmtMax = 6
ENT.produceFailChance = 20