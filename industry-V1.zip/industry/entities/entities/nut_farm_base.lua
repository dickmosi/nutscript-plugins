ENT.isWipeable = true
ENT.isOwnable = true
ENT.isFarm = true -- Don't change this otherwise seeds will not plant.
ENT.thinkFreq = 720 -- How often should the entity think? (Model updating, crop death and maintenance)

ENT.crateQualities = {
["awful"] = 1,
["poor"]= 2,
["average"] = 3,
["rich"] = 4
}

ENT.Type = "anim"
ENT.PrintName = "Farming Plot Base"
ENT.Author = "dickmosi"
ENT.Category = "NutScript - Industry"
ENT.Spawnable = false
ENT.AdminOnly = true

ENT.canCropsDie = false -- Should crops randomly die?
ENT.cropDieChance = 30 -- (0-100)

-- If crateHasQuality is false, name crates "cropname_crate" instead
ENT.crateHasQuality = true -- If true, crops produced will range in quality. Completely RNG if useFarmSkill is false.
ENT.useFarmSkill = true -- Do you want to use a farm attribute skill to dictate quality outcomes?
ENT.farmSkillAttribute = "farming"
ENT.returnSeeds = true
ENT.returnSeedsUseFarmSkill = true -- random (0-100) if false
ENT.returnSeedsChance = 60 -- (0-100) ONLY USED IF ABOVE IS FALSE

ENT.farmTier = "basic" -- Can be anything, so long as the seeds you want to plant tier match this string
ENT.flagRequired = "F"

ENT.farmModel = "models/props_junk/wood_crate001a.mdl"
ENT.modelUpdating = false -- Turn this off if you're not using custom models for the farm plots and'll rely on 'drawText' instead

if (SERVER) then
	function ENT:Initialize()
		self:SetModel(self.farmModel)
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		else
			local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

			self:PhysicsInitBox(min, max)
			self:SetCollisionBounds(min, max)
		end
	end
--SEED SOWING CODE-----------------------------------
function ENT:farmSow(seed, growthTime, farmer, bodyGroup, skin)
	if self:getNetVar("crop") == nil then
		self:setNetVar("crop", seed)
		self:farmOnSow("warn", farmer)--empty function
		self:setNetVar("farmerName", farmer:getChar():getName())
		self:setNetVar("whenGrown", os.time() + growthTime)
		
		nut.log.addRaw(farmer:getChar():getName().." has sown "..self:getNetVar("crop").." seeds.")
		self:farmOnSow("plant", farmer)--empty function
		
		if self.modelUpdating then
			if bodyGroup != nil then
				self:setNetVar("cropBodygroup", bodyGroup)
				self:SetBodygroup(self:getNetVar("cropBodygroup"), 1)
			end
			
			if skin != nil then
				self:SetSkin(skin)
			end
		end
		
		if self.canCropsDie or self.modelUpdating then
			self:setNetVar("whenSown", os.time()) -- Used for calculations
		end
		self:farmOnSow("after", farmer)--empty function
	else 
		return false
	end
end
-- Empty Functions for special unique behaviours --
function ENT:farmOnSow(state, player)
--warn (Before crop is set, to return false if a quota isn't met)
--plant
--after(crop has been planted)
end

function ENT:farmOnUse(state, player)
--warn
--harvest
--after
end

function ENT:OnTakeDamage(dmg)
	print(dmg:GetInflictor():getChar():getAttrib(self.farmSkillAttribute))
end
--
function ENT:entityWipe(complete)
	self:SetBodygroup(self:getNetVar("cropBodygroup") or 0,0)
	self:SetSkin(0)
	self:setNetVar("whenGrown", nil)
	self:setNetVar("cropBodygroup", nil)
	
	if complete != false then
		self:setNetVar("crop", nil)
		self:setNetVar("farmerName", nil)
		self:setNetVar("dead", nil)
	end
	
	if self:getNetVar("whenSown", nil) != nil then
		self:setNetVar("whenSown", nil)
	end
end
--
function ENT:entityOwnerCheck(player)
	local character = player:getChar()
	local charName = character:getName()
	local faction = character:getFaction()
	local owner = self:getNetVar("owner", nil)
	
	self.faction = false
	self.player = false
	
	if owner != nil then
		if owner == faction then
			self.faction = true
		end
		
		if owner == charName then
			self.player = true
		end
		
		return self.faction or self.player or false
	else return true end
end
--MODEL UPDATING CODE--------------------------------
function ENT:Think()
	if self:getNetVar("persistent") then
		nut.log.addRaw("ATTENTION: FARM REMOVED. Please do not persist the farms, animals or fermenting barrels as they automatically persist themselves. Manually persisting them can lead to server lag and data loss.")
		self:Remove()
	end
	
	if self.canCropsDie and self.cropDieChance != nil then
		if self:getNetVar("crop") != "dead" and self:getNetVar("crop") != nil and self:getNetVar("dead") != true then
			local growthTime = self:getNetVar("whenGrown", 0) - self:getNetVar("whenSown", 0)
			
			if self:getNetVar("whenSown") + (growthTime / 2) <= os.time() then
				self:setNetVar("dead", true)
				
				if math.random(1,100) < self.cropDieChance then
					self:entityWipe(false)
					self:setNetVar("crop", "dead")
				end
			end
		end
	end

	if self.modelUpdating and self:getNetVar("crop") != nil and self:getNetVar("crop") != "dead" then
		self:farmUpdate()
	end

	self:NextThink(CurTime() + (self.thinkFreq + math.random(0,math.floor(self.thinkFreq / 6))))
	return true
end

function ENT:farmUpdate()
	local whenGrown = self:getNetVar("whenGrown", 0)
	local whenSown = self:getNetVar("whenSown", 0)
	local growthTime =  whenGrown - whenSown

	if self.modelUpdating == true then
		if self:getNetVar("crop") != nil or self:getNetVar("crop") != "dead" then
			if whenGrown <= os.time() then -- Fully Grown
				self:SetBodygroup(self:getNetVar("cropBodygroup"), 3)
			elseif whenSown + (growthTime / 2) <= os.time() then -- Half Grown
				self:SetBodygroup(self:getNetVar("cropBodygroup"), 2)
			else end
		else -- Incase the farm update fucks up (probably shouldn't happen.)
			self:SetBodygroup(self:getNetVar("cropBodygroup") or 0, 0)
			self:SetSkin(0)
		end
	end
end
--
--HARVESTING CODE-------------------------------------
function ENT:Use(activator)
	if !self:entityOwnerCheck(activator) then
		return false
	end

	if self.flagRequired != nil and !activator:getChar():hasFlags(self.flagRequired) then
		return false
	end

	if (self.nextUse or 0) > CurTime() then
		return false
	end

	self.nextUse = CurTime() + 12

	if self.modelUpdating and self:getNetVar("crop") != nil and self:getNetVar("crop") != "dead" then
		self:farmUpdate()
	end

	if self:getNetVar("crop") != nil then
		if self:getNetVar("whenGrown", 0) <= os.time() or self:getNetVar("crop") == "dead" then
		
		if self:getNetVar("crop") != "dead" then
			if self:farmOnUse("warn", activator) == false then--empty function
				return false
			else end
		end
		
		sound.Add({
					name = "farm_harvest",
					channel = CHAN_STATIC,
					volume = 1.0,
					level = 80,
					pitch = math.random(80,100),
					sound = "metro/industry/farm/harvest.wav"
				})
		self:EmitSound("farm_harvest")
	
		local oldPos = activator:GetPos()
		
			activator:setAction("Harvesting Crops...", 8, function()
				if(activator:GetPos():Distance(oldPos) > 50) then
					activator:notify("Failed, too far away.")
					self:StopSound("farm_harvest")
					return false
				end
				
				self:StopSound("farm_harvest")
				
				if self:getNetVar("crop") == "dead" then
					self:entityWipe()
					activator:notify("You've removed the dead crops.")
				else
					self:farmOnUse("harvest", activator) --empty function
					self:entityWipe(false)
		-- CRATE SPAWN CODE
					if self.crateHasQuality then
						if self.useFarmSkill or self.farmSkillAttribute != nil then
							local charLevel = activator:getChar():getAttrib(self.farmSkillAttribute)
							local maxLevel = nut.config.get("maxAttribs", 30)
							local levelAdjust = 20 / maxLevel -- Compat for diff max attrib levels
							
							local maxSkillMod = math.ceil((maxLevel / 5) * levelAdjust)
							local playerSkill = math.floor((charLevel / maxSkillMod) * levelAdjust)
							self.finalRNG = math.random(math.max(1, playerSkill-1), math.min(playerSkill + 1,4))
						else -- useFarmSkill = false
							self.finalRNG = math.random(1,4)
						end

							for k, v in pairs(self.crateQualities) do
								if v == self.finalRNG then
									self.crateQuality = k
								end
							end

						nut.item.spawn((self:getNetVar("crop").."_crate_"..self.crateQuality), activator:getItemDropPos())
						nut.log.addRaw(activator:getChar():getName().." has gained a "..self.crateQuality.." "..self:getNetVar("crop").." crate of from farming.")
						activator:notify("You harvest the "..self.crateQuality.." quality crops and pack them into a container.")
					else -- crateHasQuality = false
						nut.item.spawn((self:getNetVar("crop").."_crate"), activator:getItemDropPos())
						nut.log.addRaw(activator:getChar():getName().." has gained a "..self:getNetVar("crop").." crate of from farming.")
						activator:notify("You harvest the crops and pack them into a container.")
					end
		-- SEED RETURN CODE
						if self.returnSeeds then
							if self.returnSeedsUseFarmSkill then
								local charLevel = activator:getChar():getAttrib(self.farmSkillAttribute)
								local maxLevel = nut.config.get("maxAttribs", 30)
								local levelAdjust = 20 / maxLevel -- Compat for diff max attrib levels
								
								if math.random(1,100) <= ((charLevel / 2) * 10)* levelAdjust then
									nut.item.spawn(("seeds_"..self:getNetVar("crop")), activator:getItemDropPos())
									activator:notify("You were able to retrieve some seeds from the "..self.PrintName)
								end
							else
								if math.random(1,100) <= self.returnSeedsChance then
									nut.item.spawn(("seeds_"..self:getNetVar("crop")), activator:getItemDropPos())
									activator:notify("You were able to retrieve some seeds from the "..self.PrintName)
								end
							end
						end
					self:farmOnUse("after", activator)
					-- self:setNetVar("crop", nil)
					self:entityWipe() -- Just incase.
				end
			end)
		else
			activator:notify("The crops haven't finished growing yet.")
		end
	else
		activator:notify("There are no crops here.")
	end
end
--
--UI CODE--------------------------------------------
else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
		
		local faction = nut.faction.indices[self:getNetVar("owner", nil)]
		
		if self:getNetVar("owner", nil) != nil then
			if faction then
				drawText("Owned by: "..faction.name.." Faction", x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			else
				drawText("Owned by: "..self:getNetVar("owner", nil), x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			end
		end

		if self:getNetVar("crop") != nil then
			if self:getNetVar("crop") != "dead" then
				local grownDate = os.date("%X %p on %d/%m/%y", self:getNetVar("whenGrown")) 
				local farmerName = self:getNetVar("farmerName", "nil") -- Displays who planted the crops
				local cropPlural = self:getNetVar("crop", nil)
				drawText("Growing "..cropPlural.." planted by "..farmerName..". Harvestable at "..grownDate, x, y+25, Color(225, 255, 225, alpha), 1, 1, nil, alpha * 0.65)
			else
				drawText("The crops are dead.", x, y+25, Color(255, 100, 100, alpha), 1, 1, nil, alpha * 0.65)
			end
		else
			drawText("Nothing is planted here.", x, y+25, Color(155, 155, 155, alpha), 1, 1, nil, alpha * 0.65)
		end
	end
end