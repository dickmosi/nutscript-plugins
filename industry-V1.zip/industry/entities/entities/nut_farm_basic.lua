ENT.Base = "nut_farm_base"
ENT.Spawnable = true
ENT.modelUpdating = true

ENT.Category = "NutScript - Industry"
ENT.PrintName = "Basic Farming Plot"
ENT.farmModel = "models/mosi/metro/farming/farm_basic.mdl"
ENT.farmTier = "basic" -- Can be anything, so long as the seeds you want to plant tier match this string

 -- Turn this off if you're not using custom models for the farm plots and'll rely on 'drawText' instead
--ENT.modelUpdateFreq = 720