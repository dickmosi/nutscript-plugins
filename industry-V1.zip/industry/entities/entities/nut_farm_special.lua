ENT.Base = "nut_farm_base"
ENT.Spawnable = true
ENT.modelUpdating = true

ENT.Category = "NutScript - Industry"
ENT.PrintName = "Special Farming Plot"
ENT.farmModel = "models/mosi/metro/farming/farm_special.mdl"
ENT.farmTier = "special" -- Can be anything, so long as the seeds you want to plant tier match this string

ENT.farmChargeCost = 20 -- How many bullets does it cost to harvest?

function ENT:farmOnSow(state, player)
	if state == "after" then
		self:EmitSound("metro/power/poweron0"..math.random(1,3)..".wav", 75, math.random(80,120), .5)
		player:notify("You will be charged "..self.farmChargeCost.." bullets, when you harvest this crop.")
	end
end

function ENT:farmOnUse(state, player)
	if state == "warn" then
		if player:getChar():getMoney() >= self.farmChargeCost then
			player:notify("You will be charged "..self.farmChargeCost.." bullets, when you harvest this crop.")
			return true
		else
			player:notify("You don't have enough bullets to cover the electricity cost.")
			return false
		end
	end
	
	if state == "harvest" then
		if player:getChar():getMoney() >= self.farmChargeCost then
			player:getChar():setMoney(player:getChar():getMoney() - self.farmChargeCost)
			
		else 
			-- They did /dropmoney during harvesting. CBA to look into preventing, this is what logs and admins are for anyway.
			-- There's a tiny chance it wasn't maliciously done, hence why no auto-ban, or kick. Leave it to admins to decide.
			nut.log.addRaw("###[!!IMPORTANT!!] "..player:getChar():getName().." is trying to exploit!!!")
			print(player:getChar():getName().." is currently exploiting :), please report this dumbo to an admin.")
			player:getChar():setName("[Exploiter]"..player:getChar():getName())
		end
	end

	if state == "after" then
		self:EmitSound("metro/power/poweroff0"..math.random(1,3)..".wav", 75, math.random(80,120), .5)
	end
end