ENT.Spawnable = true
ENT.Base = "nut_fermenting_base"

ENT.Category = "NutScript - Industry"
ENT.PrintName = "Fermenting Barrel"

ENT.fermentorModel = "models/mosi/metro/brewing/fermentingbarrel.mdl"
ENT.fermentorType = "fermenting_barrel"