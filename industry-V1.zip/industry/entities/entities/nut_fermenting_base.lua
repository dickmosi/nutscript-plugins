ENT.isWipeable = true
ENT.isOwnable = true
ENT.isFermentor = true -- Don't change this.

ENT.crateQualities = {
["awful"] = 1,
["poor"]= 2,
["average"] = 3,
["rich"] = 4
}

ENT.Type = "anim"
ENT.PrintName = "Fermentor Base"
ENT.Author = "dickmosi"
ENT.Category = "NutScript - Industry"
ENT.Spawnable = false
ENT.AdminOnly = true

ENT.fermentorModel = "models/props_c17/TrapPropeller_Engine.mdl"
ENT.fermentorType = "barrel"

ENT.flagRequired = nil

-- If crateHasQuality is false, name crates "alcoholName_crate" instead
ENT.crateHasQuality = true -- If true, crops produced will range in quality. Completely RNG if useFarmSkill is false.
ENT.useBrewingSkill = true -- Do you want to use a farm attribute skill to dictate quality outcomes?
ENT.brewingSkillAttribute = "brewing"

ENT.brewingCanFail = true
ENT.brewingFailChance = 30

if (SERVER) then
	function ENT:Initialize()
		self:SetModel(self.fermentorModel)
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		
		sound.Add({
					name = "barrel_bubble_loop",
					channel = CHAN_STATIC,
					volume = .05,
					level = 60,
					pitch = math.random(60,80),
					sound = "metro/ambience/brewing_loop.wav"
				})

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		else
			local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

			self:PhysicsInitBox(min, max)
			self:SetCollisionBounds(min, max)
		end
	end
--FILL CODE-----------------------------------
function ENT:fermentorFill(alcohol, brewTime, characterName)
	if self:getNetVar("alcohol", nil) == nil then
		self:setNetVar("alcohol", alcohol)
		self:setNetVar("characterName", characterName)
		self:setNetVar("whenBrewed", os.time() + brewTime)
		self:EmitSound("barrel_bubble_loop")
		nut.log.addRaw(characterName.." has filled a barrel with "..alcohol..".")
		self:fermentorFillUnique() -- Does nothing by default
	else 
		return false
	end
end

function ENT:entityOwnerCheck(player)
	local character = player:getChar()
	local charName = character:getName()
	local faction = character:getFaction()
	local owner = self:getNetVar("owner", nil)
	
	self.faction = false
	self.player = false
	
	if owner != nil then
		if owner == faction then
			self.faction = true
		end
		
		if owner == charName then
			self.player = true
		end
		
		return self.faction or self.player or false
	else return true end
end
-- Empty Functions for special unique behaviours --
function ENT:fermentorFillUnique()
end

function ENT:fermentorEmptyUnique()
end

function ENT:OnTakeDamage(dmg)
end
--
function ENT:entityWipe()
	self:setNetVar("whenBrewed", nil)
	self:setNetVar("characterName", nil)
	self:setNetVar("alcohol", nil)
	self:StopSound("barrel_bubble_loop")
end
--HARVESTING CODE-------------------------------------
function ENT:Use(activator)
	if !self:entityOwnerCheck(activator) then
		return false
	end

	if self.flagRequired != nil and !activator:getChar():hasFlags(self.flagRequired) then
		return false
	end

	if (self.nextUse or 0) > CurTime() then
		return false
	end

	self.nextUse = CurTime() + 7

	if self:getNetVar("alcohol") != nil then
		if self:getNetVar("whenBrewed") <= os.time() then
		
		self:EmitSound("metro/industry/brewing/brewing_start"..math.random(1,3)..".wav", 60, math.random(80,120, .33))
	
		local oldPos = activator:GetPos()
		
			activator:setAction("Emptying Barrel...", 5, function()
				if(activator:GetPos():Distance(oldPos) > 50) then
					activator:notify("Failed, too far away.")
					return false
				end
				
				self:fermentorEmptyUnique() -- Does nothing by default
				
				if self.brewingCanFail and math.random(1,100) <= self.brewingFailChance then
					self:setNetVar("whenBrewed", nil)
					self:setNetVar("characterName", nil)
					self:setNetVar("alcohol", nil)
					
					activator:notify("The alcohol brewing process has failed, the contents are ruined.")
					return false
				end
				
				self:StopSound("barrel_bubble_loop")
				activator:EmitSound("metro/industry/brewing/brewing_stop"..math.random(1,3)..".wav", 60, math.random(80,120), .33)
				
				if self.crateHasQuality then
					if self.useBrewingSkill or self.brewingSkillAttribute != nil then
						local charLevel = activator:getChar():getAttrib(self.brewingSkillAttribute)
						local maxLevel = nut.config.get("maxAttribs", 30)
						local levelAdjust = 20 / maxLevel -- Compat for diff max attrib levels
						
						local maxSkillMod = math.ceil((maxLevel / 5) * levelAdjust)
						local playerSkill = math.floor((charLevel / maxSkillMod) * levelAdjust)
						self.finalRNG = math.random(math.max(1, playerSkill-1), math.min(playerSkill + 1,4))
					else -- useBrewingSkill = false
						self.finalRNG = math.random(1,4)
					end

				for k, v in pairs(self.crateQualities) do
					if v == self.finalRNG then
						self.crateQuality = k
					end
				end

					nut.item.spawn((self:getNetVar("alcohol").."_crate_"..self.crateQuality), activator:getItemDropPos())
					nut.log.addRaw(activator:getChar():getName().." has gained a "..self.crateQuality.." "..self:getNetVar("alcohol").." crate of from brewing.")
					activator:notify("You pour the "..self.crateQuality.." quality alcohol and pack the bottles into a crate.")
				else -- crateHasQuality = false
					nut.item.spawn((self:getNetVar("alcohol").."_crate"), activator:getItemDropPos())
					nut.log.addRaw(activator:getChar():getName().." has gained a "..self:getNetVar("alcohol").." crate of from brewing.")
					activator:notify("You pour the alcohol and pack the bottles into a crate.")
				end
				self:setNetVar("whenBrewed", nil)
				self:setNetVar("characterName", nil)
				self:setNetVar("alcohol", nil)
			end)
		else
			activator:notify("The alcohol hasn't finished brewing yet.")
		end
	else
		activator:notify("The "..self.PrintName.." is empty.")
	end
end
--
--UI CODE--------------------------------------------
else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
		
		local faction = nut.faction.indices[self:getNetVar("owner", nil)]
		
		if self:getNetVar("owner", nil) != nil then
			if faction then
				drawText("Owned by: "..faction.name.." Faction", x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			else
				drawText("Owned by: "..self:getNetVar("owner", nil), x, y+45, Color(200, 255, 200, alpha), 1, 1, nil, alpha * 2)
			end
		end

		if self:getNetVar("alcohol") != nil then
			local brewDate = os.date("%X %p on %d/%m/%y", self:getNetVar("whenBrewed")) 
			local characterName = self:getNetVar("characterName") -- Displays who planted the crops
			local alcohol = self:getNetVar("alcohol")
			entDesc = ("Brewing "..alcohol.." filled by "..characterName..". Finished at "..brewDate)
		else
			entDesc = "This barrel is empty."
		end

		drawText(entDesc, x, y+25, Color(255, 255, 255, alpha), 1, 1, nil, alpha * 0.65)
	end
end