ENT.Type = "anim"
ENT.PrintName = "Foraging Base"
ENT.Author = "dickmosi"
ENT.Category = "NutScript - Foraging"
ENT.Spawnable = false
ENT.AdminOnly = true

ENT.entModel = "models/props_junk/cardboard_box001a.mdl"

ENT.resourceItem = ""
ENT.resourceAmtMin = 1
ENT.resourceAmtMax = 1

ENT.forageSFX = "" -- Leave blank for no SFX
ENT.harvestSFX = "" -- Leave blank for no SFX

ENT.canFail = false
ENT.failChance = 25
--
ENT.heightOffset = 0

ENT.yawOffsetMax = 0
ENT.yawOffsetMin = 0

ENT.pitchOffsetMax = 0
ENT.pitchOffsetMin = 0

ENT.rotationOffsetMax = 0
ENT.rotationOffsetMin = 0
--
if (SERVER) then
function ENT:Initialize()
	self:SetModel(self.entModel)
	self:SetSolid(SOLID_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	self:DrawShadow(false)

	local physObj = self:GetPhysicsObject()

	if (IsValid(physObj)) then
		physObj:EnableMotion(false)
		physObj:Sleep()
	else
		local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

		self:PhysicsInitBox(min, max)
		self:SetCollisionBounds(min, max)
	end
end

function ENT:SpawnFunction(client, trace)
	local angles = (trace.HitPos - client:GetPos()):Angle()
	angles.p = 0 + math.random(self.pitchOffsetMin or 0,self.pitchOffsetMax or 0)
	angles.r = 0 + math.random(self.rotationOffsetMin or 0,self.rotationOffsetMax or 0)
	angles.y = 0 + math.random(self.yawOffsetMin or 0,self.yawOffsetMax or 0)
	local ent = ents.Create( ClassName )
	ent:SetPos(trace.HitPos + Vector(0,0,self.heightOffset))
	ent:SetAngles(angles)
	ent:Spawn()
	
	return ent

end
	
function ENT:onFail(player)
end

function ENT:onHarvest(player)
end

function ENT:Use(activator)
	if self.harvested then
		return false
	end

	if (self.nextUse or 0) > CurTime() then
		return false
	end
	
	self.nextUse = CurTime() + 3
	

	local oldPos = activator:GetPos()
	local inventory = activator:getChar():getInv()
	
	self:EmitSound(self.forageSFX)

	activator:setAction("Foraging...", 2, function()
		if(activator:GetPos():Distance(oldPos) > 50) then
			activator:notify("Failed, too far away.")
			return false
		end
		
		self:SetBodygroup(1, 1)
		self:SetSkin(1)
		
		if self.canFail and math.random(1,100) <= self.failChance then
			self:onFail(activator)
			self.harvested = true
			return false
		end
		
		local RNG = math.random(self.resourceAmtMin or 1,self.resourceAmtMax or 1)
			
		for i= RNG,1,-1 do 
			nut.item.spawn(self.resourceItem, activator:getItemDropPos())
		end
		
		activator:notify("You sucessfully harvest the "..self.PrintName..".")
		
		self:onHarvest(activator)
		activator:EmitSound(self.harvestSFX)
		self.harvested = true
		
		self:Remove()
	end)
end

else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
	end
end