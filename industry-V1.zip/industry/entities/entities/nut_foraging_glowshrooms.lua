ENT.Spawnable = true
ENT.Base = "nut_foraging_base"

ENT.Category = "NutScript - Foraging"
ENT.PrintName = "Wild Glowshrooms"

ENT.entModel = "models/mosi/metro/foraging/plant_glowfungus.mdl"

ENT.resourceItem = "wild_glowshrooms"
ENT.resourceAmtMax = 1

ENT.harvestSFX = "npc/zombie/foot3.wav"
ENT.forageSFX = "npc/zombie/foot_slide3.wav"

ENT.yawOffsetMin = -360
ENT.yawOffsetMax = 360