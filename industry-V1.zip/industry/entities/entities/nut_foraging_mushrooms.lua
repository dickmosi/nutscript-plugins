ENT.Spawnable = true
ENT.Base = "nut_foraging_base"

ENT.Category = "NutScript - Foraging"
ENT.PrintName = "Wild Mushrooms"

ENT.entModel = "models/mosi/metro/foraging/plant_fungus.mdl"

ENT.resourceItem = "wild_mushrooms"
ENT.resourceAmtMax = 1

ENT.harvestSFX = "npc/zombie/foot3.wav"
ENT.forageSFX = "npc/zombie/foot_slide3.wav"

ENT.harvestBodygroup = true -- 0, 1

ENT.heightOffset = -1

ENT.yawOffsetMin = -360
ENT.yawOffsetMax = 360