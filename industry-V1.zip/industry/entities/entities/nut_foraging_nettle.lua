ENT.Spawnable = true
ENT.Base = "nut_foraging_base"

ENT.Category = "NutScript - Foraging"
ENT.PrintName = "Nettle Bush"

ENT.entModel = "models/mosi/metro/foraging/nettle_bush.mdl"

ENT.resourceItem = "nettlespore"
ENT.resourceAmtMin = 1
ENT.resourceAmtMax = 2

ENT.harvestSFX = "npc/barnacle/barnacle_crunch2.wav"
ENT.forageSFX = "npc/barnacle/barnacle_tongue_pull3.wav"

ENT.canFail = true
ENT.failChance = 30

ENT.heightOffset = -1

ENT.yawOffsetMin = -360
ENT.yawOffsetMax = 360
ENT.rotationOffsetMin = -8
ENT.rotationOffsetMax = 8
ENT.pitchOffsetMin = -8
ENT.pitchOffsetMax = 8


function ENT:OnTakeDamage(dmg)
	self:onFail(nil, true)
end

function ENT:Touch(entity)
	if entity.DmgPly != false and entity:IsPlayer() then
		entity.DmgPly = false
		
		self:EmitSound("weapons/bugbait/bugbait_squeeze"..math.random(1,3)..".wav", 75, math.random(130,175))
		entity:TakeDamage(math.random(2,8), self)
	
		timer.Simple(.5, function() 
			entity.DmgPly = true
		end)
	end
end

function ENT:onFail(player, damaged)
	self.harvested = true

	local effect = EffectData()
	effect:SetStart(self:GetPos())
	effect:SetOrigin(self:GetPos())
	effect:SetDamageType(8)
	effect:SetRadius(64)
	effect:SetScale(600)
	util.Effect("ThumperDust", effect)
	self:EmitSound("ambient/wind/wind_moan"..math.random(1,2)..".wav", 60, math.random(80,90), .1) --idk just sounds cool tbh.
	self:EmitSound("weapons/bugbait/bugbait_impact3.wav", 60, math.random(50,75), .75) -- too lazy to reinstall exodus for the SFX
	
	if damaged != true then
		player:TakeDamage(math.random(10,25))
	end

	self:Remove() 
end