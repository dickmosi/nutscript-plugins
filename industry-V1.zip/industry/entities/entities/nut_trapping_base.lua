ENT.Type = "anim"
ENT.PrintName = "Trapping Base"
ENT.Author = "dickmosi"
ENT.Category = "NutScript - Industry"
ENT.Spawnable = false
ENT.AdminOnly = true

ENT.trapTimerDelay = 120 -- Seconds
ENT.failChance = 30 -- 0-100 (i.e. 30 = 30% chance of failure)
ENT.canSteal = false -- Can player's check other people's traps?
ENT.singleUse = false -- If true, the trap vanishes after being checked

ENT.trapModel = "models/props_junk/cardboard_box001a.mdl"
ENT.trapResource = "" -- What the trap can yield
ENT.trapResouceAmtMax = 6 -- How many of the resource the trap can yield at most
ENT.trapResouceAmtMin = nil -- Just remove this if you don't want RNG

ENT.trapItem = "" -- The trap's item form name (For recollection)



if (SERVER) then
	function ENT:Initialize()
		self:SetModel(self.trapModel)
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		
		self:EmitSound("physics/wood/wood_crate_impact_soft"..math.random(1,3)..".wav", 100, math.random(60,80))
		self:setNetVar("trapTimer", os.time() + self.trapTimerDelay)

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		else
			local min, max = Vector(-8, -8, -8), Vector(8, 8, 8)

			self:PhysicsInitBox(min, max)
			self:SetCollisionBounds(min, max)
		end
	end

function ENT:OnTakeDamage(damage)
	local client = damage:GetInflictor()
end

function ENT:Use(activator)
	if activator:IsPlayer() then
		if (self.nextUse or 0) > CurTime() then
			return false
		end
	
		self.nextUse = CurTime() + 4
	else return false end

	if !self.canSteal and !(activator:getChar():getID() == self:getNetVar("owner")) then -- If people can't steal traps, and ID is false
		activator:notify("You do not own this trap.")
		return false
	end
	
	if self:getNetVar("trapTimer") < os.time() then

		activator:EmitSound("npc/barnacle/barnacle_tongue_pull3.wav", 100, math.random(40,60))

		local oldPos = activator:GetPos()
		local inventory = activator:getChar():getInv()
		local freeSpot = inventory:findFreePosition(self.trapResource)

		activator:setAction("Checking Trap...", 3, function()
			if(activator:GetPos():Distance(oldPos) > 50) then
				activator:notify("Failed, too far away.")
				return false
			end
			-- RNG CHECK
			if trapResouceAmtMin != nil then
				self.trapResourceAmt = math.random(self.trapResouceAmtMin, self.trapResouceAmtMax)
			else
				self.trapResourceAmt = self.trapResouceAmtMax
			end
			-- Fail Chance and Item Spawn Code
			if math.random(1,100) > self.failChance then 
				activator:notify("You find something in the trap.")
				
				for i= self.trapResourceAmt,1,-1 do 
					nut.item.spawn(self.trapResource, activator:getItemDropPos())
				end
				activator:EmitSound("npc/barnacle/neck_snap"..math.random(1,2)..".wav")
			else
				activator:notify("The bait is gone, but the trap is empty.")
			end
			activator:EmitSound("physics/cardboard/cardboard_box_impact_hard"..math.random(1,7)..".wav")
			
			if !singleUse then nut.item.spawn(self.trapItem, activator:getItemDropPos()) end
			self:Remove()
		end)
	end
end

else
	function ENT:Draw()
		self:DrawModel()
	end

	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.Name or self.PrintName, x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
			
		if self:getNetVar("trapTimer") < os.time() then
			drawText("This trap has been disturbed", x, y+25, Color(255, 155, 155, alpha), 1, 1, nil, alpha * 0.65)
		else
			drawText("This trap is undisturbed", x, y+25, Color(230, 255, 230, alpha), 1, 1, nil, alpha * 0.65)
		end
	end
end