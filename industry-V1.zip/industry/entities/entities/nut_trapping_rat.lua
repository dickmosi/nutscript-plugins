ENT.Base = "nut_trapping_base"
ENT.Spawnable = false
ENT.PrintName = "Rat Trap"

ENT.trapTimerDelay = 120 -- Seconds
ENT.failChance = 35 -- 0-100 (i.e. 30 = 30% chance of failure)
ENT.canSteal = false -- Can player's check other people's traps?
ENT.singleUse = false -- If true, the trap vanishes after being checked

ENT.trapModel = "models/mosi/metro/hunting/rat_trap.mdl"
ENT.trapResource = "rat" -- What the trap can yield
ENT.trapResouceAmtMax = 4 -- How many of the resource the trap can yield at most
ENT.trapResouceAmtMin = 1 -- Just remove this if you don't want RNG

ENT.trapItem = "trap_rat" -- The trap's item form name (For recollection)