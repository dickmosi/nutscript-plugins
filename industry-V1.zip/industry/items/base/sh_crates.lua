ITEM.name = "Crate Base"
ITEM.desc = ""
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"
ITEM.category = "Industry - Crates"
ITEM.price = 100

ITEM.crateItem = nil -- What item does the crate contain?
ITEM.crateQuantity = 1

ITEM.functions.Open = {
	name = "Open Crate",
	icon = "icon16/cog_go.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		
		for i= item.crateQuantity,1,-1 do 
			if inventory:findFreePosition(item.crateItem) == nil then
				nut.item.spawn(item.crateItem, client:getItemDropPos())
			else
				inventory:add(item.crateItem)
			end
		end
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity) and item.crateItem != nil)
	end
}

if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		draw.SimpleText(item.crateQuantity, "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end