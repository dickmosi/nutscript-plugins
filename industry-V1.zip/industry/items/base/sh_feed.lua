ITEM.name = "animal Base"
ITEM.desc = ""
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.category = "Industry - Animals"

ITEM.flagRequired = nil -- Change to the required flag or to nil to disable it

ITEM.animalType = nil -- What animal does this feed?
ITEM.produceWaitTime = 600 -- How many seconds until the crop is fully grown

ITEM.functions.FeedAnimal = {
	name = "Feed Animals",
	icon = "icon16/cog_go.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		local entity = client:GetEyeTraceNoCursor().Entity
		
		if entity.isFarmAnimal and entity.animalType == item.animalType then
			if flagRequired != nil and !character:hasFlags(flagRequired) then
				client:notify("You need the \""..flagRequired.."\" flag to feed these animals.")
			end
			
		local charName = character:getName()
		local faction = character:getFaction()
		local owner = entity:getNetVar("owner", nil)
		
		item.faction = false
		item.player = false
		
		if owner != nil then
			if owner == faction then
				item.faction = true
			end
			
			if owner == charName then
				item.player = true
			end
			
			if item.faction or item.player == false then
				client:notify("You do not have permission to feed these animals.")
				return false
			end
		else end
			
			if entity:getNetVar("whenCheckable", nil) == nil then
				entity:animalFeed(item.produceWaitTime, client:getChar():getName())
				client:notify("You feed the animals in the "..entity.PrintName)
			else
				client:notify("These animals aren't hungry yet.")
				return false
			end
		else
			client:notify("You can't feed that this food.")
			return false
		end
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity)) and item.animalType != nil
	end
}