ITEM.name = "We do nothing, replace us!"
ITEM.desc = "pls"
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"