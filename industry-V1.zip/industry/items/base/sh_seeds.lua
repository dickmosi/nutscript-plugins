ITEM.name = "Seed Base"
ITEM.desc = ""
ITEM.model = "models/mosi/metro/farming/crops/item_seedpack.mdl"
ITEM.category = "Industry - Farming"

ITEM.flagRequired = "F" -- Change to the required flag or to nil to disable it

ITEM.cropType = nil -- What crop does this seed plant?
ITEM.cropTier = "" -- What farm tier (basic/standard/advanced) Must match farm entity's tier
ITEM.cropGrowthTime = 60 -- How many seconds until the crop is fully grown

ITEM.cropBodygroup = nil -- (OPTIONAL) What bodygroup the farm model should switch to
ITEM.cropSkin = nil -- (OPTIONAL) What skin the farm model should switch to

ITEM.functions.PlantSeed = {
	name = "Plant Seed",
	icon = "icon16/cog_go.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		local entity = client:GetEyeTraceNoCursor().Entity
		
		local charName = character:getName()
		local faction = character:getFaction()
		local owner = entity:getNetVar("owner", nil)
		
		item.faction = false
		item.player = false
		
		if owner != nil then
			if owner == faction then
				item.faction = true
				print("faction true")
			end
			
			if owner == charName then
				item.player = true
				print("player true")
			end
			
			if item.faction or item.player == false then
				client:notify("You do not have permission to plant these here.")
				return false
			end
		else end
		
		-- Checks to see if the entity is a farm, and if the cropTier matches up.
		if entity.isFarm and entity.farmTier == item.cropTier then
			-- Flag check
			if flagRequired != nil and !character:hasFlags(flagRequired) then
				client:notify("You need the \""..flagRequired.."\" flag to plant these.")
			end
			-- Checks to see if the farm already has something planted
			if entity:getNetVar("crop", nil) == nil then
				entity:farmSow(item.cropType, item.cropGrowthTime, client, item.cropBodygroup, item.cropSkin)
				client:notify("You sow the seeds into the "..entity.PrintName.."'s soil")
			else
				client:notify("There is already something planted here!")
				return false
			end
		else
			client:notify("You cannot plant these here")
			return false
		end
		-- return false
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity)) and item.cropType != nil
	end
}