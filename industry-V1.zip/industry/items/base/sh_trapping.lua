--[[
TO DO:
General Cleanup & Comments
--]]


ITEM.name = "Trapping Base"
ITEM.desc = ""
ITEM.model = "models/props_junk/meathook001a.mdl"
ITEM.category = "Industry - Trapping"

ITEM.baitItem = nil
ITEM.trapEntity = ""

ITEM.functions.SetTrap = {
	name = "Setup Trap",
	icon = "icon16/arrow_down.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		
		if item.baitItem != nil and !inventory:hasItem(item.baitItem) then
			client:notify("You need bait to setup this trap.")
			return false
		end

		client:EmitSound("npc/barnacle/barnacle_tongue_pull3.wav")
		
		local oldPos = client:GetPos()
		
		client:setAction("Setting Trap...", 6, function()
			if(client:GetPos():Distance(oldPos) > 50) then
				client:notify("Failed, too far away.")
				return false
			end
			
			if item.baitItem != nil then
				inventory:getFirstItemOfType(item.baitItem):remove()
				client:EmitSound("weapons/bugbait/bugbait_squeeze3.wav", 100, math.random(60,120))
			end

			local entity = ents.Create(item.trapEntity)
			local angles = client:GetAimVector():Angle() -- Finds out which direction the player is facing.
				angles.r = 0
				angles.p = 0
	
			entity:SetPos(client:EyePos() + client:GetAimVector() * 64)
			entity:SetAngles(angles)
			entity:DropToFloor()
			entity:setNetVar("owner", character:getID())
			entity:Spawn()
			entity:Activate()
			entity:SetCreator(client)
			
			item:remove()
		end)
		return false -- Prevents premature item removal
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity)) -- The item has to be in a player's inventory for this option to show
	end
}