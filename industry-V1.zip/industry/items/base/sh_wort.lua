ITEM.name = "Wort R Those?! Base"
ITEM.desc = "" -- A mid step between crop and alcohol, to allow for more varation with less crops. Requires a crafting plugin.
ITEM.model = "models/mosi/metro/brewing/items/item_wort.mdl"
ITEM.skin = 0 -- (0-3 skin: 0 Wort, 1 Mash, 2 Mush, 3 Must)
ITEM.category = "Industry - Brewing"

--ITEM.flagRequired = "B" -- Change to the required flag or to nil to disable it
ITEM.flagRequired = nil

ITEM.alcoholType = nil -- What item does this brew into?
ITEM.fermentorType = "fermenting_barrel" -- What does this go into?
ITEM.brewTime = 1 -- How many seconds until the brewing is finished

ITEM.functions.Ferment = {
	name = "Pour into Fermentor",
	icon = "icon16/cog_go.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		local entity = client:GetEyeTraceNoCursor().Entity
		
		local charName = character:getName()
		local faction = character:getFaction()
		local owner = entity:getNetVar("owner", nil)
		
		item.faction = false
		item.player = false
		
		if owner != nil then
			if owner == faction then
				item.faction = true
				print("faction true")
			end
			
			if owner == charName then
				item.player = true
				print("player true")
			end
			
			if item.faction or item.player == false then
				client:notify("You do not have permission to use this fermentor.")
				return false
			end
		else end

		if entity.isFermentor and entity.fermentorType == item.fermentorType then
			-- Flag check
			if flagRequired != nil and !character:hasFlags(flagRequired) then
				client:notify("You need the \""..flagRequired.."\" flag to ferment this.")
			end
			-- is sumfin' brewin' 'ere m8?
			if entity:getNetVar("alcohol", nil) == nil then
				entity:fermentorFill(item.alcoholType, item.brewTime, character:getName())
				client:notify("You fill up the "..entity.PrintName.." with "..item.name)
			else
				client:notify("There is already something already in the "..entity.PrintName.."!")
				return false
			end
		else
			client:notify("You cannot ferment this in here.")
			return false
		end
	end,
	onCanRun = function(item)
		return (!IsValid(item.entity)) and item.alcoholType != nil
	end
}