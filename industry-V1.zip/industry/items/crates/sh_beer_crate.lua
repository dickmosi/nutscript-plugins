ITEM.name = "Crate of Beer"
ITEM.desc = "A crate of freshly brewed mushroom beer"
ITEM.model = "models/mosi/metro/brewing/items/crate_alcohol03.mdl"
ITEM.price = 90

ITEM.crateItem = "beer"
ITEM.crateQuantity = 12