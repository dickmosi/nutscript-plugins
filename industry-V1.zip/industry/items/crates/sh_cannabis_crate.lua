-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Cannabis Bud Carton"
ITEM.desc = "A cartoon filled with Cannabis Buds."
ITEM.model = "models/mosi/metro/misc/items/cigarettecarton.mdl"

ITEM.crateItem = "cannabis"
ITEM.crateQuantity = 12
ITEM.price = 80