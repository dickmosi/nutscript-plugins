ITEM.name = "Cannabis Bud Carton [Awful]"
ITEM.desc = "A cartoon filled with Cannabis Buds."
ITEM.model = "models/mosi/metro/misc/items/cigarettecarton.mdl"

ITEM.crateItem = "cannabis"
ITEM.crateQuantity = 12
ITEM.price = 80