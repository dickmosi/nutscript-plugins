ITEM.name = "Cannabis Bud Carton [Rich]"
ITEM.desc = "A cartoon filled to the brim with Cannabis Buds."
ITEM.model = "models/mosi/metro/misc/items/cigarettecarton.mdl"

ITEM.crateItem = "cannabis"
ITEM.crateQuantity = 16
ITEM.price = 112