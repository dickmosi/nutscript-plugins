-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Carrot Crate"
ITEM.desc = "A crate filled with Carrots"
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"

ITEM.crateItem = "carrot"
ITEM.crateQuantity = 18
ITEM.price = 47