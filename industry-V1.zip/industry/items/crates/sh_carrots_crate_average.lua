ITEM.name = "Carrot Crate [Average]"
ITEM.desc = "A crate filled with potatoes."
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"

ITEM.crateItem = "carrot"
ITEM.crateQuantity = 18
ITEM.price = 47