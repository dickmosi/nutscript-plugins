ITEM.name = "Carrot Crate [Awful]"
ITEM.desc = "A half full crate of carrots."
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"

ITEM.crateItem = "carrot"
ITEM.crateQuantity = 9
ITEM.price = 24