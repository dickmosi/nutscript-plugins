ITEM.name = "Carrot Crate [Poor]"
ITEM.desc = "A nearly full crate of carrots."
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"

ITEM.crateItem = "carrot"
ITEM.crateQuantity = 12
ITEM.price = 35