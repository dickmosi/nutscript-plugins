ITEM.name = "Carrot Crate [Rich]"
ITEM.desc = "A crate filled to the brim with Carrots."
ITEM.model = "models/mosi/metro/farming/crops/sealed_crate.mdl"

ITEM.crateItem = "carrot"
ITEM.crateQuantity = 24
ITEM.price = 59