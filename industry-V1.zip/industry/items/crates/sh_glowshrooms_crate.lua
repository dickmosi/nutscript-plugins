-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Crate of Glowshrooms"
ITEM.desc = "A crate filled with luminescent mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/glowshroom_crate.mdl"

ITEM.crateItem = "glowshroom"
ITEM.crateQuantity = 14
ITEM.price = 60