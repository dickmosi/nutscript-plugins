ITEM.name = "Crate of Glowshrooms [Average]"
ITEM.desc = "A crate filled with luminescent mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/glowshroom_crate.mdl"

ITEM.crateItem = "glowshroom"
ITEM.crateQuantity = 14
ITEM.price = 60