ITEM.name = "Crate of Glowshrooms [Awful]"
ITEM.desc = "A half filled crate of luminescent mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/glowshroom_crate.mdl"

ITEM.crateItem = "glowshroom"
ITEM.crateQuantity = 7
ITEM.price = 35