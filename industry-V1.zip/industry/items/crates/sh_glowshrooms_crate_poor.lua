ITEM.name = "Crate of Glowshrooms [Poor]"
ITEM.desc = "A nearly full crate of luminescent mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/glowshroom_crate.mdl"

ITEM.crateItem = "glowshroom"
ITEM.crateQuantity = 10
ITEM.price = 50