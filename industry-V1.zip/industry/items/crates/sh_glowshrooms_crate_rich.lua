ITEM.name = "Crate of Glowshrooms [Rich]"
ITEM.desc = "A crate filled to the brim with luminescent mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/glowshroom_crate.mdl"

ITEM.crateItem = "glowshroom"
ITEM.crateQuantity = 18
ITEM.price = 85