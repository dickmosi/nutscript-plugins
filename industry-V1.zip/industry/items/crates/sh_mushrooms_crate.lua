-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Crate of Mushrooms"
ITEM.desc = "A crate filled with mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/mushroom_crate.mdl"

ITEM.crateItem = "mushroom"
ITEM.crateQuantity = 16
ITEM.price = 56