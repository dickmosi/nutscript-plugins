ITEM.name = "Crate of Mushrooms [Average]"
ITEM.desc = "A crate filled with mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/mushroom_crate.mdl"

ITEM.crateItem = "mushroom"
ITEM.crateQuantity = 16
ITEM.price = 56