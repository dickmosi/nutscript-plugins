ITEM.name = "Crate of Mushrooms [Awful]"
ITEM.desc = "A half filled crate of mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/mushroom_crate.mdl"

ITEM.crateItem = "mushroom"
ITEM.crateQuantity = 8
ITEM.price = 27