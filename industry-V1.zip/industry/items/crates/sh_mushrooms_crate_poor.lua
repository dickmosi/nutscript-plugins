ITEM.name = "Crate of Mushrooms [Poor]"
ITEM.desc = "A nearly full crate of mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/mushroom_crate.mdl"

ITEM.crateItem = "mushroom"
ITEM.crateQuantity = 12
ITEM.price = 40