ITEM.name = "Crate of Mushrooms [Rich]"
ITEM.desc = "A crate filled to the brim with mushrooms."
ITEM.model = "models/mosi/metro/farming/crops/mushroom_crate.mdl"

ITEM.crateItem = "mushroom"
ITEM.crateQuantity = 20
ITEM.price = 70