-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Sack of Potatoes"
ITEM.desc = "A burlap sack filled with potatoes."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "potato"
ITEM.crateQuantity = 20
ITEM.price = 45