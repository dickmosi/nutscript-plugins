ITEM.name = "Sack of Potatoes [Average]"
ITEM.desc = "A burlap sack filled with potatoes."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "potato"
ITEM.crateQuantity = 20
ITEM.price = 45