ITEM.name = "Sack of Potatoes [Awful]"
ITEM.desc = "A half filled burlap sack of potatoes."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "potato"
ITEM.crateQuantity = 10
ITEM.price = 22