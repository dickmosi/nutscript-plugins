ITEM.name = "Sack of Potatoes [Rich]"
ITEM.desc = "A burlap sack filled to the brim with potatoes."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "potato"
ITEM.crateQuantity = 25
ITEM.price = 56