-- This item is a fallback item, incase you disable quality crates. it's identical to an average crate.
ITEM.name = "Sack of Wheat"
ITEM.desc = "A burlap sack filled with Wheat."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "wheat"
ITEM.crateQuantity = 8
ITEM.price = 74