ITEM.name = "Sack of Wheat [Average]"
ITEM.desc = "A burlap sack filled with Wheat."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "wheat"
ITEM.crateQuantity = 8
ITEM.price = 74