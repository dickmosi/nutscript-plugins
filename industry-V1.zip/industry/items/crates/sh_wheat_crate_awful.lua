ITEM.name = "Sack of Wheat [Awful]"
ITEM.desc = "A half filled burlap sack of Wheat."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "wheat"
ITEM.crateQuantity = 4
ITEM.price = 35