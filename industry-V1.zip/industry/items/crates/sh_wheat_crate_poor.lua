ITEM.name = "Sack of Wheat [Poor]"
ITEM.desc = "A nearly full burlap sack of Wheat."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "wheat"
ITEM.crateQuantity = 6
ITEM.price = 56