ITEM.name = "Sack of Wheat [Rich]"
ITEM.desc = "A burlap sack filled to the brim with Wheat."
ITEM.model = "models/mosi/metro/farming/crops/item_sack.mdl"

ITEM.crateItem = "wheat"
ITEM.crateQuantity = 10
ITEM.price = 96