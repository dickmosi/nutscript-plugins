ITEM.name = "Pig Feed"
ITEM.desc = "A bag containing animal feed for pigs, it doesn't look very appetising to you."

ITEM.animalType = "pigs" -- What animal does this feed?
ITEM.produceWaitTime = 28800