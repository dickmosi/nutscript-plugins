ITEM.name = "Rat Feed"
ITEM.desc = "A small bag containing animal feed for rats, it doesn't look very appetising to you."

ITEM.animalType = "rats" -- What animal does this feed?
ITEM.produceWaitTime = 7200