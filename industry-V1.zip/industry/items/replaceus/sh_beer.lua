-- Replace with your own more complex/less useless item.
ITEM.name = "Beer"
ITEM.desc = "A brown bottle of locally brewed mushroom beer, it has an earthy taste to it."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"