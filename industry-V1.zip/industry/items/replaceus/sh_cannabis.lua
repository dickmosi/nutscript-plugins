-- Replace with your own more complex/less useless item.
ITEM.name = "Cannabis Buds"
ITEM.desc = "A box containg a couple buds"
ITEM.model = "models/props_lab/box01b.mdl"