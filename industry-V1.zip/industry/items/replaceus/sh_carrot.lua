-- Replace with your own more complex/less useless item.
ITEM.name = "Carrot"
ITEM.desc = "A fresh carrot"
ITEM.model = "models/mosi/metro/farming/crops/carrot.mdl"