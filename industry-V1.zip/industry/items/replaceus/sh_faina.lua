-- Replace with your own more complex/less useless item.
ITEM.name = "\"Faina\""
ITEM.desc = "A bottle of metro-made mushroom brandy, brewed and bottled in Kartooshka itself. It has a pleasant earthy flavour and is quite aromatic."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"