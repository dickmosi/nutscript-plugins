-- Replace with your own more complex/less useless item.
ITEM.name = "Glowshroom"
ITEM.desc = "A raw luminescent green mushroom"
ITEM.model = "models/mosi/metro/farming/crops/glowshroom.mdl"