-- Replace with your own more complex/less useless item.
ITEM.name = "Samogon"
ITEM.desc = "A cloudy bottle of metro-made moonshine."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"