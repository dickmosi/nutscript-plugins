-- Replace with your own more complex/less useless item.
ITEM.name = "Mushroom"
ITEM.desc = "A raw Mushroom"
ITEM.model = "models/mosi/metro/farming/crops/mushroom.mdl"