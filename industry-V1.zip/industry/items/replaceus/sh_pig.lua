-- Replace with your own more complex/less useless item.
ITEM.name = "Pig"
ITEM.desc = "A deceased pig"
ITEM.model = "models/mosi/metro/animals/item/pig_carcass.mdl"

ITEM.category = "Industry - Animals"