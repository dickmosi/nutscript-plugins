-- Replace with your own more complex/less useless item.
ITEM.name = "Potato"
ITEM.desc = "A fresh potato. Boil 'em, mash 'em, stick 'em in a stew."
ITEM.model = "models/mosi/metro/farming/crops/potato.mdl"