-- Replace with your own more complex/less useless item.
ITEM.name = "Rat"
ITEM.desc = "A deceased rat"
ITEM.model = "models/fallout 3/iguana_stick.mdl"

ITEM.category = "Industry - Animals"