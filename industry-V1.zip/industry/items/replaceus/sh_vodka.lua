-- Replace with your own more complex/less useless item.
ITEM.name = "Mushroom Vodka"
ITEM.desc = "A bottle of Mushroom vodka."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"