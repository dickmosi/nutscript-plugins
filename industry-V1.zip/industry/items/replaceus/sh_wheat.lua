-- Replace with your own more complex/less useless item.
ITEM.name = "Bundle of Wheat"
ITEM.desc = "A bundle of fresh wheat"
ITEM.model = "models/mosi/metro/farming/crops/wheatbundle.mdl"