ITEM.name = "Cannabis Seeds"
ITEM.desc = "A small packet containing cannabis seeds, these can be used to grow cannabis in special farming plots"

ITEM.flagRequired = "F"

ITEM.cropType = "cannabis"
ITEM.cropTier = "special"
ITEM.cropGrowthTime = 86400

ITEM.cropBodygroup = 2
ITEM.cropSkin = 1