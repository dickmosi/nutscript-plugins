ITEM.name = "Carrot Seeds"
ITEM.desc = "A small bag containing carrot seeds which can be used to grow carrots in basic farming plots"

ITEM.flagRequired = "F"

ITEM.cropType = "carrots"
ITEM.cropTier = "basic"
ITEM.cropGrowthTime = 28800

ITEM.cropBodygroup = 2
ITEM.cropSkin = 1