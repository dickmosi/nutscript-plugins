ITEM.name = "Glowshroom Spawn"
ITEM.desc = "A small box containing glowshroom spawn which can be used to grow glowshrooms in basic farming plots"
ITEM.color = {0, 255, 0}

ITEM.flagRequired = "F"

ITEM.cropType = "glowshrooms"
ITEM.cropTier = "basic"
ITEM.cropGrowthTime = 28800

ITEM.cropBodygroup = 1
ITEM.cropSkin = 2