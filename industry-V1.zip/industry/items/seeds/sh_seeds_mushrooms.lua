ITEM.name = "Mushroom Spawn"
ITEM.desc = "A small box containing mushroom spawn which can be used to grow mushrooms in basic farming plots"

ITEM.flagRequired = "F" -- Change to the required flag or to nil to disable it

ITEM.cropType = "mushrooms" -- What crop does this seed plant? (Must be plural i.e. Mushrooms, potatoes etc.)
ITEM.cropTier = "basic" -- What farm tier (basic/standard/advanced) Should hopefully support custom tiers
ITEM.cropGrowthTime = 28800 -- How many seconds until the crop is fully grown

ITEM.cropBodygroup = 1 -- (OPTIONAL) What bodygroup the farm model should switch to
ITEM.cropSkin = 1 -- (OPTIONAL) What skin the farm model should switch to