ITEM.name = "Seed Potatoes"
ITEM.desc = "A small bag containing sliced seed potatoes which can be used to grow potatoes in basic farming plots"

ITEM.flagRequired = "F"

ITEM.cropType = "potatoes"
ITEM.cropTier = "basic"
ITEM.cropGrowthTime = 28800

ITEM.cropBodygroup = 2
ITEM.cropSkin = 1