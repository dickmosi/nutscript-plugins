ITEM.name = "Wheat Seeds"
ITEM.desc = "A small box containing wheat seeds, these can be used to grow wheat in special farming plots"

ITEM.flagRequired = "F"

ITEM.cropType = "wheat"
ITEM.cropTier = "special"
ITEM.cropGrowthTime = 86400

ITEM.cropBodygroup = 1
ITEM.cropSkin = 1