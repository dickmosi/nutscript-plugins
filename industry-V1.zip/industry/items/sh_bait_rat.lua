ITEM.name = "Rat Bait"
ITEM.desc = "An awful smelling paste-like mixture of bugs and mushrooms"
ITEM.category = "Industry - Trapping"
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"