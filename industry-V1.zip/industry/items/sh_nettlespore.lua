ITEM.name = "Nettle Spore Sack" -- This is a crafting ingredient
ITEM.desc = "An egg shaped sack of spores extracted from a \"Nettle\" plant. These sacks are dangerous to obtain but can be cut open, gutted and dried out as a tobacco substitute. The resulting cigarettes are stronger in taste, health effects and benefits compared to pre-war cigarettes."
ITEM.model = "models/mosi/metro/foraging/items/item_nettle_spore.mdl"
ITEM.category = "Industry - Foraging"