ITEM.name = "Wild Mushrooms"
ITEM.desc = "Wild Mushrooms"
ITEM.model = "models/mosi/metro/foraging/items/item_wildfungus.mdl"
ITEM.category = "Industry - Foraging"

ITEM.requiredFlag = "F"
ITEM.rawItem = "mushroom"
ITEM.rawItemAmt = 3
ITEM.seeds = "seeds_mushrooms"

ITEM.functions.ConvertSeed = {
	name = "Convert into Seeds",
	icon = "icon16/arrow_refresh.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		local freeSpot = inventory:findFreePosition(item.seeds)
		
		client:notify("You convert the "..item.name.." into seeds.")
		
		if freeSpot == nil then
			nut.item.spawn(item.seeds, client:getItemDropPos())
		else
			inventory:add(item.seeds)
		end
	end,
	onCanRun = function(item)-- remove code from "and" onwards, if you don't want this behind flags.
		return !IsValid(item.entity) and item.player:getChar():hasFlags(item.requiredFlag)
	end
}

ITEM.functions.ConvertItem = {
	name = "Seperate Mushrooms",
	icon = "icon16/arrow_divide.png",
	onRun = function(item)
		local client = item.player
		local character = client:getChar()
		local inventory = character:getInv()
		local freeSpot = inventory:findFreePosition(item.rawItem)
		
		client:notify("You seperate the "..item.name..". (x"..item.rawItemAmt..")")
		
		for i= item.rawItemAmt,1,-1 do 
			if freeSpot == nil then
				nut.item.spawn(item.rawItem, client:getItemDropPos())
			else
				inventory:add(item.rawItem)
			end
		end
	end,
	onCanRun = function(item)
		return !IsValid(item.entity)
	end
}