ITEM.name = "Rat Trap Kit"
ITEM.desc = "A small trap kit comprised of a bucket and planks"
ITEM.model = "models/mosi/metro/hunting/rat_trap_item.mdl"
-- If you don't want your item to require bait, just remove the ITEM.baitItem line.
ITEM.baitItem = "bait_rat"
ITEM.trapEntity = "nut_trapping_rat" -- MUST be set to the name of your trap entity otherwise it won't work.