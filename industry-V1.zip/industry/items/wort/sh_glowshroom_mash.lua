ITEM.name = "Mushroom Mash [Vodka]"
ITEM.desc = "Unfermented mushroom vodka. This needs to ferment in a fermenting barrel before it can become drinkable."
ITEM.skin = 1

ITEM.alcoholType = "vodka" -- What crop does this seed plant? (Must be plural i.e. Mushrooms, potatoes etc.)
ITEM.brewTime = 90 -- How many seconds until the crop is fully grown