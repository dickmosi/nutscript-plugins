ITEM.name = "Mushroom Wort [Beer]"
ITEM.desc = "Unfermented mushroom beer. This needs to ferment in a fermenting barrel before it can become drinkable."
ITEM.skin = 0

ITEM.alcoholType = "beer" -- What crop does this seed plant? (Must be plural i.e. Mushrooms, potatoes etc.)
ITEM.brewTime = 90 -- How many seconds until the crop is fully grown