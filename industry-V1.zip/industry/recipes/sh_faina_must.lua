CRAFTING.name = "Mushroom Must [Faina]"
CRAFTING.category = "Brewing"
CRAFTING.recipe = {
	{"glowshroom", 8},
	{"mushroom", 4},
	{"potato", 1}
}
CRAFTING.result = {
	{"faina_must", 1}
}