CRAFTING.name = "Glowshroom Mash"
CRAFTING.category = "Brewing"
CRAFTING.recipe = {
	{"glowshroom", 12},
}
CRAFTING.result = {
	{"glowshroom_mash", 1}
}