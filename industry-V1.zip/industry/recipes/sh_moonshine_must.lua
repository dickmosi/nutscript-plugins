CRAFTING.name = "Moonshine Mush"
CRAFTING.category = "Brewing"
CRAFTING.recipe = {
	{"potato", 8},
}
CRAFTING.result = {
	{"moonshine_mush", 1}
}