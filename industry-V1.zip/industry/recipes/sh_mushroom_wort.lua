CRAFTING.name = "Mushroom Wort"
CRAFTING.category = "Brewing"
CRAFTING.recipe = {
	{"mushroom", 12},
}
CRAFTING.result = {
	{"mushroom_wort", 1}
}