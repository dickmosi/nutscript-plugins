-- v1.0
-- do whatever you want with the contents of this addon.
PLUGIN.name = "Industry: Husbandry, Farming, brewing and foraging"
PLUGIN.desc = "Adds Farming, brewing, animal trapping, foraging and more to Nutscript."
PLUGIN.author = "dickmosi"
-- Required by default: https://steamcommunity.com/sharedfiles/filedetails/?id=2795784568

--[[
NOTES:

Apologies that everything is a mess, I kinda gave up 60% the way through.
Feature creep didn't help. God Speed.

!!!THE CROPNAME SHOULD MATCH OR ERRORS WILL HAPPEN!!!
Seed = seeds_CROPNAME
Seed cropType = CROPNAME
crate = CROPNAME_crate (+_quality) if crateQuality is enabled on farm_base
--]]
nut.flag.add("F", "Access to Farming and Animal Husbandry.")
-- nut.flag.add("B", "Access to Brewing.")

nut.command.add("entitywipe", {
    adminOnly = true,
	onRun = function(client, arguments)
		local entity = client:GetEyeTraceNoCursor().Entity
		
		if entity.isWipeable then
			client:notify(entity.PrintName.." has been wiped.")
			entity:entityWipe()
		else
			client:notify("You must be looking at a wipeable entity (farm, animal or fermentor) to do this.")
		end
	end
})

nut.command.add("entitysetowner", {
    adminOnly = true,
	syntax = "[player/faction]",
	onRun = function(client, arguments)
		local entity = client:GetEyeTraceNoCursor().Entity
		
		if entity.isOwnable then
			local faction
			local player
			
			-- Check if the player supplied a faction name.
			if (arguments[1]) then
				-- Get all of the arguments as one string.
				local name = table.concat(arguments, " ")

				-- Loop through each faction, checking the uniqueID and name.
				for k, v in pairs(nut.faction.teams) do
					if (nut.util.stringMatches(k, name) or nut.util.stringMatches(L(v.name, client), name)) then
						-- This faction matches the provided string.
						faction = v

						-- Escape the poop.
						break
					end
				end
			end

			-- Check if a faction was found.
			if (faction) then
				entity.nutFactionID = faction.uniqueID
				entity:setNetVar("owner", faction.index)

				client:notify("Set owner to faction "..faction.name)
			-- The faction was not found.
			elseif (arguments[1]) then
				local player = nut.command.findPlayer(client, arguments[1])
				
				if (IsValid(player)) then
					entity:setNetVar("owner", player:getChar():getName()) -- Lazy, easy to break, I know :(
				else
					client:notify("Unable to find a valid player or faction associated with that name.")
				end
			else
				entity:setNetVar("owner", nil)
				client:notify("Ownership removed")
			end
		end
	end
})
-- may lord have mercy elseif may allah have mercy else im boned
if SERVER then

function PLUGIN:LoadData()
	local savedTable = self:getData() or {}

	for k, v in ipairs(savedTable) do
		local position = v.position
		local angles = v.angles
		local entity = ents.Create(v.class)
		
		entity:SetPos(v.pos)
		entity:SetAngles(v.ang)
		entity:Spawn()
		entity:Activate()
		
		if v.class == "nut_farm_basic" or v.class == "nut_farm_special" then
			entity:setNetVar("crop", v.crop)
			entity:setNetVar("farmerName", v.farmerName)
			entity:setNetVar("whenGrown", v.whenGrown)
			entity:setNetVar("whenSown", v.whenSown)
			entity:setNetVar("dead", v.dead)
			entity:setNetVar("cropBodygroup", v.bodygroup)
			entity:setNetVar("owner", v.owner)
			entity:SetBodygroup(v.bodygroup, v.currentBodygroup)
			entity:SetSkin(v.skin)
		elseif v.class == "nut_fermenting_barrel" then
			entity:setNetVar("alcohol", v.alcohol)
			entity:setNetVar("characterName", v.charName)
			entity:setNetVar("whenBrewed", v.whenBrewed)
			entity:setNetVar("owner", v.owner)
		elseif v.class == "nut_animal_pigs" or v.class == "nut_animal_rats" then
			entity:setNetVar("characterName", v.charName)
			entity:setNetVar("whenCheckable", v.whenCheckable)
			entity:setNetVar("owner", v.owner)
		else
			print(v.class.."UNKNOWN ENTITY SAVED. PLEASE SETUP THE ENTITY RESTORING CORRECTLY IN THE INDUSTRY PLUGIN SH_PLUGIN.LUA")
			error("Unkown Entity in industry save data", 1)
		end
	end
end

function PLUGIN:SaveData()
	local savedTable = {}

		for k, v in ipairs(ents.GetAll()) do
			if (v.isFarm) then
				table.insert(savedTable, 
				{
				class = v:GetClass(),
				pos = v:GetPos(), 
				ang = v:GetAngles(), 
				crop = v:getNetVar("crop", nil),
				farmerName = v:getNetVar("farmerName", nil),
				whenGrown = v:getNetVar("whenGrown", nil),
				whenSown = v:getNetVar("whenSown", nil),
				dead = v:getNetVar("dead", nil),
				bodygroup = v:getNetVar("cropBodygroup", 0),
				currentBodygroup = v:GetBodygroup(v:getNetVar("cropBodygroup", 0)),
				skin = v:GetSkin(),
				owner = v:getNetVar("owner", nil),
				})
			end
			
			if (v.isFermentor) then
				table.insert(savedTable, 
				{
				class = v:GetClass(),
				pos = v:GetPos(), 
				ang = v:GetAngles(), 
				alcohol = v:getNetVar("alcohol", nil),
				charName = v:getNetVar("characterName", nil),
				whenBrewed = v:getNetVar("whenBrewed", nil),
				owner = v:getNetVar("owner", nil),
				})
			end
			
			if (v.isFarmAnimal) then
				table.insert(savedTable, 
				{
				class = v:GetClass(),
				pos = v:GetPos(), 
				ang = v:GetAngles(), 
				charName = v:getNetVar("characterName", nil),
				whenCheckable = v:getNetVar("whenCheckable", nil),
				owner = v:getNetVar("owner", nil),
				})
			end
		end

		self:setData(savedTable)
	end
end