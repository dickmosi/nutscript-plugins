ENT.Type = "anim"
ENT.PrintName = "Paper"
ENT.Author = "Black Tea"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "NutScript"

if (SERVER) then

	function ENT:Initialize()
		self:SetModel("models/props_c17/paper01.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:setNetVar("text", "")
		self:SetUseType(SIMPLE_USE)
		local physicsObject = self:GetPhysicsObject()
		if (IsValid(physicsObject)) then
			physicsObject:Wake()
		end
	end

	function ENT:Use(activator)
		activator:OpenNote( self:getNetVar( "text" ), self, self:getNetVar( "private" ) )
	end
	
else

	function ENT:Draw()
		self:DrawModel()
	end
	
	ENT.DrawEntityInfo = true
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y
		drawText(self.PrintName, x, y-50, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 2)
		if self:getNetVar("private") == true then
			drawText("Private", x, y-25, Color(255, 100, 100, alpha), 1, 1, nil, alpha * 0.65)
		end
	end
end